var mes = prompt("Escriba el número del mes")
switch(mes) {

 case "1":
 case "2":
 case "12":
   console.log("Es invierno")
   console.log("no. carnet: 22006166 nombre: Héctor Gerardo Sigüenza Morales")
   break;
  case "3":
  case "4":
  case "5":
    console.log("Es primavera")
    console.log("no. carnet: 22006166 nombre: Héctor Gerardo Sigüenza Morales")
   break;
  case "6":
  case "7":
  case "8":
    console.log("Es verano")
    console.log("no. carnet: 22006166 nombre: Héctor Gerardo Sigüenza Morales")
   break;
  case "9":
  case "10":
  case "11":
    console.log("Es otoño")
    console.log("no. carnet: 22006166 nombre: Héctor Gerardo Sigüenza Morales")
   break;
   default:
    console.log("Ingrese un numero entre 1 y 12")

} 